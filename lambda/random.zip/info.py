db_host = "svc-db.cfmlcsyhy0vk.ap-northeast-2.rds.amazonaws.com"
db_username = "root"
db_password = "random123"
db_name = "random"
db_port = 3306
winner_num = 2
source = "rhghwls0716@hanmail.net"
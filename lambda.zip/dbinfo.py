db_host = ""
db_username = "root"
db_password = "random123"
db_name = "random"
db_port = 3306